// routes/index.js
const express    = require('express');
const router     = express.Router();
const { isAuthenticated, isAdmin } = require('../middleware/auth');

const authCtrl      = require('../controllers/authController');
const dashCtrl      = require('../controllers/dashboardController');
const banVeCtrl     = require('../controllers/banVeController');
const tayEmCtrl     = require('../controllers/tayEmController');
const doanhThuCtrl  = require('../controllers/doanhThuController');
const db            = require('../config/database');

// ── AUTH ──────────────────────────────────────────────────────
router.get( '/auth/login',         authCtrl.loginPage);
router.post('/auth/login',         authCtrl.loginAction);
router.get( '/auth/logout',        authCtrl.logout);
router.get( '/auth/doi-mat-khau',  isAuthenticated, authCtrl.changePasswordPage);
router.post('/auth/doi-mat-khau',  isAuthenticated, authCtrl.changePasswordAction);

// Redirect root → dashboard
router.get('/', (req, res) => res.redirect('/dashboard'));

// ── DASHBOARD ─────────────────────────────────────────────────
router.get('/dashboard', isAuthenticated, dashCtrl.index);

// ── BÁN VÉ HÀNG NGÀY ─────────────────────────────────────────
router.get( '/ban-ve/hom-nay',          isAuthenticated, banVeCtrl.homNay);
router.get( '/ban-ve/hom-qua',          isAuthenticated, banVeCtrl.homQua);
router.get( '/ban-ve/ngay-mai',         isAuthenticated, banVeCtrl.ngayMai);
router.get( '/ban-ve/chon-ngay',        isAuthenticated, banVeCtrl.chonNgay);
router.post('/ban-ve/them',             isAuthenticated, banVeCtrl.themVe);
router.post('/ban-ve/sua/:id',          isAuthenticated, banVeCtrl.suaVe);
router.post('/ban-ve/xoa/:id',          isAuthenticated, banVeCtrl.xoaVe);
router.post('/ban-ve/tick-da-dang',     isAuthenticated, banVeCtrl.tickDaDang);
router.post('/ban-ve/luu-du-lieu',      isAuthenticated, banVeCtrl.luuDuLieu);

// ── TAY EM ────────────────────────────────────────────────────
router.get( '/tay-em',             isAuthenticated, tayEmCtrl.index);
router.post('/tay-em/them',        isAuthenticated, tayEmCtrl.them);
router.post('/tay-em/sua/:id',     isAuthenticated, tayEmCtrl.sua);
router.post('/tay-em/xoa/:id',     isAuthenticated, isAdmin, tayEmCtrl.xoa);
router.get( '/tay-em/nghi-phep',   isAuthenticated, tayEmCtrl.nghiPhep);
router.post('/tay-em/nghi-phep',   isAuthenticated, tayEmCtrl.themNghiPhep);

// ── ĐẠI LÝ ───────────────────────────────────────────────────
router.get('/dai-ly', isAuthenticated, async (req, res) => {
    const [rows] = await db.query('SELECT * FROM dai_ly ORDER BY ten_dai_ly');
    res.render('pages/dai-ly/index', { title: 'Quản Lý Đại Lý', rows });
});
router.post('/dai-ly/them', isAuthenticated, isAdmin, async (req, res) => {
    const { ten_dai_ly, dia_chi, so_dien_thoai, email } = req.body;
    await db.query('INSERT INTO dai_ly (ten_dai_ly, dia_chi, so_dien_thoai, email) VALUES (?,?,?,?)',
        [ten_dai_ly, dia_chi, so_dien_thoai, email]);
    req.flash('success', 'Thêm đại lý thành công'); res.redirect('/dai-ly');
});
router.post('/dai-ly/sua/:id', isAuthenticated, isAdmin, async (req, res) => {
    const { ten_dai_ly, dia_chi, so_dien_thoai, email } = req.body;
    await db.query('UPDATE dai_ly SET ten_dai_ly=?,dia_chi=?,so_dien_thoai=?,email=? WHERE id=?',
        [ten_dai_ly, dia_chi, so_dien_thoai, email, req.params.id]);
    req.flash('success', 'Cập nhật thành công'); res.redirect('/dai-ly');
});
router.post('/dai-ly/xoa/:id', isAuthenticated, isAdmin, async (req, res) => {
    await db.query('DELETE FROM dai_ly WHERE id=?', [req.params.id]);
    req.flash('success', 'Đã xóa đại lý'); res.redirect('/dai-ly');
});

// ── GIÁ VÉ / CẤU HÌNH HỆ THỐNG ───────────────────────────────
router.get('/cau-hinh/gia-ve', isAuthenticated, isAdmin, async (req, res) => {
    const [rows] = await db.query('SELECT * FROM gia_ve ORDER BY ngay_trong_tuan, tinh_thanh');
    res.render('pages/cau-hinh/gia-ve', { title: 'Cấu Hình Giá Vé', rows });
});
router.post('/cau-hinh/gia-ve/sua/:id', isAuthenticated, isAdmin, async (req, res) => {
    const { ten_tuyen, ngay_trong_tuan, tinh_thanh, gia_ve } = req.body;
    await db.query('UPDATE gia_ve SET ten_tuyen=?,ngay_trong_tuan=?,tinh_thanh=?,gia_ve=? WHERE id=?',
        [ten_tuyen, ngay_trong_tuan, tinh_thanh, gia_ve, req.params.id]);
    req.flash('success', 'Cập nhật giá vé thành công'); res.redirect('/cau-hinh/gia-ve');
});

// ── DOANH THU ─────────────────────────────────────────────────
router.get('/doanh-thu/theo-ngay',   isAuthenticated, doanhThuCtrl.theoNgay);
router.get('/doanh-thu/theo-thang',  isAuthenticated, doanhThuCtrl.theoThang);
router.get('/doanh-thu/theo-cam',    isAuthenticated, doanhThuCtrl.theoCam);

module.exports = router;

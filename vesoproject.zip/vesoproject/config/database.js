// config/database.js
const mysql = require('mysql2');
require('dotenv').config();

// Tạo connection pool (tốt hơn single connection)
const pool = mysql.createPool({
    host:     process.env.DB_HOST     || 'localhost',
    port:     process.env.DB_PORT     || 3306,
    user:     process.env.DB_USER     || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME     || 'veso_db',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
    charset: 'utf8mb4',
    timezone: '+07:00', // Giờ Việt Nam
});

// Xuất dạng promise để dùng async/await
const db = pool.promise();

// Kiểm tra kết nối khi khởi động
pool.getConnection((err, connection) => {
    if (err) {
        console.error('❌ Kết nối MySQL thất bại:', err.message);
        if (err.code === 'PROTOCOL_CONNECTION_LOST') {
            console.error('   → Mất kết nối với database server');
        } else if (err.code === 'ER_CON_COUNT_ERROR') {
            console.error('   → Database quá nhiều kết nối');
        } else if (err.code === 'ECONNREFUSED') {
            console.error('   → Kết nối database bị từ chối. Kiểm tra MySQL đang chạy chưa?');
        } else if (err.code === 'ER_ACCESS_DENIED_ERROR') {
            console.error('   → Sai user/password trong file .env');
        }
        return;
    }
    if (connection) {
        connection.release();
        console.log('✅ Kết nối MySQL thành công!');
        console.log(`   → Host: ${process.env.DB_HOST}:${process.env.DB_PORT}`);
        console.log(`   → Database: ${process.env.DB_NAME}`);
    }
});

module.exports = db;

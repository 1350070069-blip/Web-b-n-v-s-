// controllers/dashboardController.js
const db     = require('../config/database');
const moment = require('moment');

const index = async (req, res) => {
    try {
        const today = moment().format('YYYY-MM-DD');
        const thang = moment().format('YYYY-MM');
        const nam   = moment().format('YYYY');

        // Tổng vé nhận hôm nay
        const [[{ tong_ve_nhan }]] = await db.query(
            `SELECT COALESCE(SUM(so_ve_ban + so_ve_e), 0) AS tong_ve_nhan FROM ban_ve WHERE ngay_ban = ?`, [today]
        );
        // Tổng vé bán hôm nay
        const [[{ tong_ve_ban }]] = await db.query(
            `SELECT COALESCE(SUM(so_ve_ban), 0) AS tong_ve_ban FROM ban_ve WHERE ngay_ban = ?`, [today]
        );
        // Tổng vé ế hôm nay
        const [[{ tong_ve_e }]] = await db.query(
            `SELECT COALESCE(SUM(so_ve_e), 0) AS tong_ve_e FROM ban_ve WHERE ngay_ban = ?`, [today]
        );
        // Tổng tiền đăng hôm nay
        const [[{ tong_tien }]] = await db.query(
            `SELECT COALESCE(SUM(tien_dang), 0) AS tong_tien FROM ban_ve WHERE ngay_ban = ?`, [today]
        );
        // Số tay em đã đăng hôm nay
        const [[{ so_da_dang }]] = await db.query(
            `SELECT COUNT(*) AS so_da_dang FROM ban_ve WHERE ngay_ban = ? AND da_dang = 1`, [today]
        );
        // Số tay em chưa đăng (có trong danh sách nhưng chưa đăng)
        const [[{ so_chua_dang }]] = await db.query(
            `SELECT COUNT(*) AS so_chua_dang FROM tay_em WHERE trang_thai = 'hoat_dong'`
        );
        // Doanh thu theo tháng (cho biểu đồ)
        const [doanhThuThang] = await db.query(
            `SELECT DAY(ngay_ban) AS ngay, SUM(tien_dang) AS doanh_thu
             FROM ban_ve WHERE DATE_FORMAT(ngay_ban, '%Y-%m') = ?
             GROUP BY DAY(ngay_ban) ORDER BY ngay`, [thang]
        );
        // Top 10 tay em bán nhiều nhất
        const [top10] = await db.query(
            `SELECT te.ho_ten, SUM(bv.so_ve_ban) AS tong_ban
             FROM ban_ve bv JOIN tay_em te ON bv.tay_em_id = te.id
             WHERE DATE_FORMAT(bv.ngay_ban, '%Y-%m') = ?
             GROUP BY te.id ORDER BY tong_ban DESC LIMIT 10`, [thang]
        );
        // Tay em chưa đăng hôm nay
        const [chuaDang] = await db.query(
            `SELECT te.ho_ten FROM tay_em te
             WHERE te.trang_thai = 'hoat_dong'
             AND te.id NOT IN (SELECT tay_em_id FROM ban_ve WHERE ngay_ban = ?)`, [today]
        );

        res.render('pages/dashboard', {
            title: 'Trang Chủ',
            stats: { tong_ve_nhan, tong_ve_ban, tong_ve_e, tong_tien, so_da_dang, so_chua_dang },
            doanhThuThang: JSON.stringify(doanhThuThang),
            top10: JSON.stringify(top10),
            chuaDang,
            today: moment().format('DD/MM/YYYY'),
        });
    } catch (err) {
        console.error(err);
        res.render('pages/dashboard', { title: 'Trang Chủ', stats: {}, doanhThuThang: '[]', top10: '[]', chuaDang: [] });
    }
};

module.exports = { index };

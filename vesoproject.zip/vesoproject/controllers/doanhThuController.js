// controllers/doanhThuController.js
const db     = require('../config/database');
const moment = require('moment');

// Thống kê ngày
const theoNgay = async (req, res) => {
    const ngay = req.query.ngay || moment().format('YYYY-MM-DD');
    const [rows] = await db.query(
        `SELECT te.ho_ten,
                SUM(bv.so_ve_ban)   AS tong_ve_ban,
                SUM(bv.so_ve_e)     AS tong_ve_e,
                SUM(bv.so_ve_ban + bv.so_ve_e) AS ve_nhan,
                SUM(bv.tien_dang)   AS tong_tien
         FROM ban_ve bv JOIN tay_em te ON bv.tay_em_id = te.id
         WHERE bv.ngay_ban = ?
         GROUP BY te.id ORDER BY tong_tien DESC`, [ngay]
    );
    const [[tong]] = await db.query(
        `SELECT SUM(so_ve_ban) AS ve_ban, SUM(so_ve_e) AS ve_e, SUM(tien_dang) AS tien
         FROM ban_ve WHERE ngay_ban = ?`, [ngay]
    );
    res.render('pages/doanh-thu/theo-ngay', {
        title: 'Thống Kê Ngày',
        rows, tong,
        ngay,
        ngayHienThi: moment(ngay).format('DD/MM/YYYY'),
    });
};

// Thống kê tháng
const theoThang = async (req, res) => {
    const thang = req.query.thang || moment().format('YYYY-MM');
    const [rows] = await db.query(
        `SELECT te.ho_ten,
                SUM(bv.so_ve_ban) AS tong_ve_ban,
                SUM(bv.so_ve_e)   AS tong_ve_e,
                SUM(bv.tien_dang) AS tong_tien
         FROM ban_ve bv JOIN tay_em te ON bv.tay_em_id = te.id
         WHERE DATE_FORMAT(bv.ngay_ban,'%Y-%m') = ?
         GROUP BY te.id ORDER BY tong_tien DESC`, [thang]
    );
    const [[tong]] = await db.query(
        `SELECT SUM(so_ve_ban) AS ve_ban, SUM(so_ve_e) AS ve_e, SUM(tien_dang) AS tien
         FROM ban_ve WHERE DATE_FORMAT(ngay_ban,'%Y-%m') = ?`, [thang]
    );
    // Biểu đồ theo ngày trong tháng
    const [bieu_do] = await db.query(
        `SELECT DAY(ngay_ban) AS ngay, SUM(tien_dang) AS doanh_thu
         FROM ban_ve WHERE DATE_FORMAT(ngay_ban,'%Y-%m') = ?
         GROUP BY DAY(ngay_ban) ORDER BY ngay`, [thang]
    );
    res.render('pages/doanh-thu/theo-thang', {
        title: 'Thống Kê Tháng',
        rows, tong,
        thang,
        bieu_do: JSON.stringify(bieu_do),
    });
};

// Thống kê cắm (nợ/chưa thu)
const theoCam = async (req, res) => {
    const thang = req.query.thang || moment().format('YYYY-MM');
    const [rows] = await db.query(
        `SELECT te.ho_ten,
                SUM(bv.tien_dang) AS tong_tien,
                SUM(CASE WHEN bv.da_dang = 0 THEN bv.tien_dang ELSE 0 END) AS chua_dang
         FROM ban_ve bv JOIN tay_em te ON bv.tay_em_id = te.id
         WHERE DATE_FORMAT(bv.ngay_ban,'%Y-%m') = ?
         GROUP BY te.id HAVING chua_dang > 0 ORDER BY chua_dang DESC`, [thang]
    );
    res.render('pages/doanh-thu/theo-cam', { title: 'Thống Kê Cắm', rows, thang });
};

module.exports = { theoNgay, theoThang, theoCam };

// controllers/authController.js
const bcrypt = require('bcrypt');
const db     = require('../config/database');

// GET /auth/login
const loginPage = (req, res) => {
    if (req.session.user) return res.redirect('/dashboard');
    res.render('pages/login', { title: 'Đăng Nhập' });
};

// POST /auth/login
const loginAction = async (req, res) => {
    const { username, password } = req.body;
    try {
        const [rows] = await db.query(
            'SELECT * FROM users WHERE username = ? AND trang_thai = 1',
            [username]
        );
        if (rows.length === 0) {
            req.flash('error', 'Tài khoản không tồn tại hoặc đã bị khóa');
            return res.redirect('/auth/login');
        }
        const user  = rows[0];
        const match = await bcrypt.compare(password, user.password);
        if (!match) {
            req.flash('error', 'Mật khẩu không đúng');
            return res.redirect('/auth/login');
        }
        // Lưu session
        req.session.user = {
            id:      user.id,
            username: user.username,
            ho_ten:  user.ho_ten,
            role:    user.role,
        };
        // Cập nhật last_login
        await db.query('UPDATE users SET last_login = NOW() WHERE id = ?', [user.id]);
        res.redirect('/dashboard');
    } catch (err) {
        console.error(err);
        req.flash('error', 'Lỗi hệ thống, vui lòng thử lại');
        res.redirect('/auth/login');
    }
};

// GET /auth/logout
const logout = (req, res) => {
    req.session.destroy(() => {
        res.redirect('/auth/login');
    });
};

// GET /auth/doi-mat-khau
const changePasswordPage = (req, res) => {
    res.render('pages/doi-mat-khau', { title: 'Đổi Mật Khẩu' });
};

// POST /auth/doi-mat-khau
const changePasswordAction = async (req, res) => {
    const { mat_khau_cu, mat_khau_moi, xac_nhan } = req.body;
    if (mat_khau_moi !== xac_nhan) {
        req.flash('error', 'Xác nhận mật khẩu không khớp');
        return res.redirect('/auth/doi-mat-khau');
    }
    try {
        const [rows] = await db.query('SELECT * FROM users WHERE id = ?', [req.session.user.id]);
        const match  = await bcrypt.compare(mat_khau_cu, rows[0].password);
        if (!match) {
            req.flash('error', 'Mật khẩu cũ không đúng');
            return res.redirect('/auth/doi-mat-khau');
        }
        const hashed = await bcrypt.hash(mat_khau_moi, 10);
        await db.query('UPDATE users SET password = ? WHERE id = ?', [hashed, req.session.user.id]);
        req.flash('success', 'Đổi mật khẩu thành công');
        res.redirect('/dashboard');
    } catch (err) {
        console.error(err);
        req.flash('error', 'Lỗi hệ thống');
        res.redirect('/auth/doi-mat-khau');
    }
};

module.exports = { loginPage, loginAction, logout, changePasswordPage, changePasswordAction };

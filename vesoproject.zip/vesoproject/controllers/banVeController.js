// controllers/banVeController.js
const db     = require('../config/database');
const moment = require('moment');

// ─── HÔM NAY ────────────────────────────────────────────────
const homNay = async (req, res) => {
    const today = moment().format('YYYY-MM-DD');
    const [rows] = await db.query(
        `SELECT bv.*, te.ho_ten, gv.ten_tuyen, gv.gia_ve
         FROM ban_ve bv
         JOIN tay_em te ON bv.tay_em_id = te.id
         JOIN gia_ve gv ON bv.gia_ve_id = gv.id
         WHERE bv.ngay_ban = ? ORDER BY bv.id DESC`, [today]
    );
    const [tayEm] = await db.query(`SELECT * FROM tay_em WHERE trang_thai = 'hoat_dong' ORDER BY ho_ten`);
    const [giaVe] = await db.query(`SELECT * FROM gia_ve WHERE trang_thai = 1 ORDER BY ten_tuyen`);
    res.render('pages/ban-ve/hom-nay', {
        title: 'Quản Lý Vé Hôm Nay',
        rows, tayEm, giaVe,
        today: moment().format('DD/MM/YYYY'),
    });
};

// ─── HÔM QUA ────────────────────────────────────────────────
const homQua = async (req, res) => {
    const yesterday = moment().subtract(1, 'days').format('YYYY-MM-DD');
    const [rows] = await db.query(
        `SELECT bv.*, te.ho_ten, gv.ten_tuyen, gv.gia_ve
         FROM ban_ve bv
         JOIN tay_em te ON bv.tay_em_id = te.id
         JOIN gia_ve gv ON bv.gia_ve_id = gv.id
         WHERE bv.ngay_ban = ? ORDER BY bv.id DESC`, [yesterday]
    );
    res.render('pages/ban-ve/hom-qua', {
        title: 'Dữ Liệu Hôm Qua',
        rows,
        yesterday: moment().subtract(1, 'days').format('DD/MM/YYYY'),
    });
};

// ─── NGÀY MAI ────────────────────────────────────────────────
const ngayMai = async (req, res) => {
    const tomorrow     = moment().add(1, 'days').format('YYYY-MM-DD');
    const thuNgayMai   = moment().add(1, 'days').isoWeekday() + 1; // 2-8
    const [danhSach]   = await db.query(
        `SELECT te.id, te.ho_ten FROM tay_em te WHERE te.trang_thai = 'hoat_dong' ORDER BY te.ho_ten`
    );
    res.render('pages/ban-ve/ngay-mai', {
        title: 'Chuẩn Bị Ngày Mai',
        danhSach,
        tomorrow: moment().add(1, 'days').format('DD/MM/YYYY'),
    });
};

// ─── CHỌN NGÀY BẤT KỲ ────────────────────────────────────────
const chonNgay = async (req, res) => {
    const ngay   = req.query.ngay || moment().format('YYYY-MM-DD');
    const lichSu = req.query.lich_su === '1';
    let rows = [];
    if (!lichSu) {
        [rows] = await db.query(
            `SELECT bv.*, te.ho_ten, gv.ten_tuyen, gv.gia_ve
             FROM ban_ve bv
             JOIN tay_em te ON bv.tay_em_id = te.id
             JOIN gia_ve gv ON bv.gia_ve_id = gv.id
             WHERE bv.ngay_ban = ? ORDER BY bv.id DESC`, [ngay]
        );
    }
    res.render('pages/ban-ve/chon-ngay', {
        title: 'Chọn Ngày Bất Kỳ',
        rows,
        ngay,
        lichSu,
        ngayHienThi: moment(ngay).format('DD/MM/YYYY'),
    });
};

// ─── THÊM VÉ ─────────────────────────────────────────────────
const themVe = async (req, res) => {
    const { tay_em_id, gia_ve_id, ngay_ban, so_ve_ban, so_ve_e, ghi_chu } = req.body;
    const tien_dang = parseInt(so_ve_ban || 0);
    // Lấy giá vé để tính tiền
    const [[gv]] = await db.query('SELECT gia_ve FROM gia_ve WHERE id = ?', [gia_ve_id]);
    const tien    = tien_dang * (gv ? gv.gia_ve : 0);
    await db.query(
        `INSERT INTO ban_ve (tay_em_id, gia_ve_id, ngay_ban, so_ve_ban, so_ve_e, tien_dang, ghi_chu, nguoi_nhap)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [tay_em_id, gia_ve_id, ngay_ban, so_ve_ban || 0, so_ve_e || 0, tien, ghi_chu, req.session.user.id]
    );
    req.flash('success', 'Thêm vé thành công');
    res.redirect('/ban-ve/hom-nay');
};

// ─── SỬA VÉ ──────────────────────────────────────────────────
const suaVe = async (req, res) => {
    const { id } = req.params;
    const { so_ve_ban, so_ve_e, da_dang, ghi_chu } = req.body;
    const [[bv]] = await db.query('SELECT * FROM ban_ve WHERE id = ?', [id]);
    const [[gv]] = await db.query('SELECT gia_ve FROM gia_ve WHERE id = ?', [bv.gia_ve_id]);
    const tien   = parseInt(so_ve_ban || 0) * (gv ? gv.gia_ve : 0);
    await db.query(
        `UPDATE ban_ve SET so_ve_ban=?, so_ve_e=?, tien_dang=?, da_dang=?, ghi_chu=? WHERE id=?`,
        [so_ve_ban || 0, so_ve_e || 0, tien, da_dang ? 1 : 0, ghi_chu, id]
    );
    req.flash('success', 'Cập nhật thành công');
    res.redirect('back');
};

// ─── XÓA VÉ ──────────────────────────────────────────────────
const xoaVe = async (req, res) => {
    await db.query('DELETE FROM ban_ve WHERE id = ?', [req.params.id]);
    req.flash('success', 'Đã xóa');
    res.redirect('back');
};

// ─── TICK ĐÃ ĐĂNG ─────────────────────────────────────────────
const tickDaDang = async (req, res) => {
    const { ids } = req.body; // mảng id
    if (ids && ids.length) {
        await db.query(`UPDATE ban_ve SET da_dang = 1 WHERE id IN (?)`, [ids]);
    }
    req.flash('success', 'Đã đánh dấu đã đăng');
    res.redirect('back');
};

// ─── LƯU DỮ LIỆU (bulk) ──────────────────────────────────────
const luuDuLieu = async (req, res) => {
    const { records } = req.body; // JSON array
    try {
        const arr = JSON.parse(records);
        for (const r of arr) {
            const [[gv]] = await db.query('SELECT gia_ve FROM gia_ve WHERE id = ?', [r.gia_ve_id]);
            const tien   = parseInt(r.so_ve_ban || 0) * (gv ? gv.gia_ve : 0);
            await db.query(
                `INSERT INTO ban_ve (tay_em_id, gia_ve_id, ngay_ban, so_ve_ban, so_ve_e, tien_dang, nguoi_nhap)
                 VALUES (?, ?, ?, ?, ?, ?, ?)
                 ON DUPLICATE KEY UPDATE so_ve_ban=VALUES(so_ve_ban), so_ve_e=VALUES(so_ve_e), tien_dang=VALUES(tien_dang)`,
                [r.tay_em_id, r.gia_ve_id, r.ngay_ban, r.so_ve_ban || 0, r.so_ve_e || 0, tien, req.session.user.id]
            );
        }
        res.json({ success: true });
    } catch (e) {
        res.json({ success: false, message: e.message });
    }
};

module.exports = { homNay, homQua, ngayMai, chonNgay, themVe, suaVe, xoaVe, tickDaDang, luuDuLieu };

// controllers/tayEmController.js
const db = require('../config/database');

const index = async (req, res) => {
    const { search, trang_thai } = req.query;
    let sql  = `SELECT te.*, dl.ten_dai_ly FROM tay_em te LEFT JOIN dai_ly dl ON te.dai_ly_id = dl.id WHERE 1=1`;
    const params = [];
    if (search) { sql += ` AND te.ho_ten LIKE ?`; params.push(`%${search}%`); }
    if (trang_thai) { sql += ` AND te.trang_thai = ?`; params.push(trang_thai); }
    sql += ` ORDER BY te.ho_ten`;
    const [rows]   = await db.query(sql, params);
    const [daiLy]  = await db.query(`SELECT * FROM dai_ly WHERE trang_thai = 1`);
    res.render('pages/tay-em/index', { title: 'Quản Lý Tay Em', rows, daiLy, search, trang_thai });
};

const them = async (req, res) => {
    const { ho_ten, so_dien_thoai, dia_chi, dai_ly_id, ngay_bat_dau_lam, ghi_chu } = req.body;
    await db.query(
        `INSERT INTO tay_em (ho_ten, so_dien_thoai, dia_chi, dai_ly_id, ngay_bat_dau_lam, ghi_chu) VALUES (?,?,?,?,?,?)`,
        [ho_ten, so_dien_thoai, dia_chi, dai_ly_id || null, ngay_bat_dau_lam || null, ghi_chu]
    );
    req.flash('success', `Thêm tay em "${ho_ten}" thành công`);
    res.redirect('/tay-em');
};

const sua = async (req, res) => {
    const { ho_ten, so_dien_thoai, dia_chi, dai_ly_id, trang_thai, ngay_bat_dau_lam, ghi_chu } = req.body;
    await db.query(
        `UPDATE tay_em SET ho_ten=?, so_dien_thoai=?, dia_chi=?, dai_ly_id=?, trang_thai=?, ngay_bat_dau_lam=?, ghi_chu=? WHERE id=?`,
        [ho_ten, so_dien_thoai, dia_chi, dai_ly_id || null, trang_thai, ngay_bat_dau_lam || null, ghi_chu, req.params.id]
    );
    req.flash('success', 'Cập nhật thành công');
    res.redirect('/tay-em');
};

const xoa = async (req, res) => {
    await db.query('DELETE FROM tay_em WHERE id = ?', [req.params.id]);
    req.flash('success', 'Đã xóa tay em');
    res.redirect('/tay-em');
};

// Quản lý nghỉ phép
const nghiPhep = async (req, res) => {
    const [rows] = await db.query(
        `SELECT np.*, te.ho_ten FROM nghi_phep np JOIN tay_em te ON np.tay_em_id = te.id ORDER BY np.ngay_bat_dau_nghi DESC LIMIT 50`
    );
    const [tayEm] = await db.query(`SELECT id, ho_ten FROM tay_em WHERE trang_thai = 'hoat_dong' ORDER BY ho_ten`);
    res.render('pages/tay-em/nghi-phep', { title: 'Quản Lý Nghỉ Phép', rows, tayEm });
};

const themNghiPhep = async (req, res) => {
    const { tay_em_id, ngay_bat_dau_nghi, ngay_ket_thuc_nghi, loai_nghi, ly_do } = req.body;
    await db.query(
        `INSERT INTO nghi_phep (tay_em_id, ngay_bat_dau_nghi, ngay_ket_thuc_nghi, loai_nghi, ly_do) VALUES (?,?,?,?,?)`,
        [tay_em_id, ngay_bat_dau_nghi, ngay_ket_thuc_nghi || null, loai_nghi, ly_do]
    );
    // Cập nhật trạng thái tay em
    const trangThai = loai_nghi === '1_ngay' ? 'nghi_1_ngay' : 'nghi_nhieu_ngay';
    await db.query(`UPDATE tay_em SET trang_thai = ? WHERE id = ?`, [trangThai, tay_em_id]);
    req.flash('success', 'Đã ghi nhận nghỉ phép');
    res.redirect('/tay-em/nghi-phep');
};

module.exports = { index, them, sua, xoa, nghiPhep, themNghiPhep };

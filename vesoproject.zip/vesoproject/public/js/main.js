// public/js/main.js

// ── ĐỒNG HỒ ──────────────────────────────────────────────────
function updateClock() {
    const el = document.getElementById('clock');
    if (!el) return;
    const now = new Date();
    el.textContent = now.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}
setInterval(updateClock, 1000);
updateClock();

// ── SIDEBAR TOGGLE (mobile) ───────────────────────────────────
const sidebarToggle = document.getElementById('sidebarToggle');
const sidebar       = document.getElementById('sidebar');
if (sidebarToggle && sidebar) {
    sidebarToggle.addEventListener('click', () => {
        sidebar.classList.toggle('open');
    });
}

// ── HIGHLIGHT ACTIVE NAV ──────────────────────────────────────
const currentPath = window.location.pathname;
document.querySelectorAll('.nav-item').forEach(a => {
    if (a.getAttribute('href') === currentPath) {
        a.classList.add('active');
    }
});

// ── AUTO DISMISS FLASH ────────────────────────────────────────
setTimeout(() => {
    document.querySelectorAll('.alert').forEach(el => {
        el.style.transition = 'opacity 0.5s';
        el.style.opacity = '0';
        setTimeout(() => el.remove(), 500);
    });
}, 4000);

// ── FORMAT TIỀN ──────────────────────────────────────────────
function formatTien(n) {
    return new Intl.NumberFormat('vi-VN').format(n) + 'đ';
}

// ── CONFIRM XÓA ───────────────────────────────────────────────
document.querySelectorAll('form[data-confirm]').forEach(form => {
    form.addEventListener('submit', e => {
        if (!confirm(form.dataset.confirm || 'Bạn có chắc muốn xóa?')) {
            e.preventDefault();
        }
    });
});

// middleware/auth.js

// Kiểm tra đã đăng nhập chưa
const isAuthenticated = (req, res, next) => {
    if (req.session && req.session.user) {
        return next();
    }
    req.flash('error', 'Vui lòng đăng nhập để tiếp tục');
    res.redirect('/auth/login');
};

// Kiểm tra quyền admin
const isAdmin = (req, res, next) => {
    if (req.session && req.session.user && req.session.user.role === 'admin') {
        return next();
    }
    req.flash('error', 'Bạn không có quyền truy cập trang này');
    res.redirect('/dashboard');
};

// Gắn thông tin user vào res.locals (dùng trong view)
const setLocals = (req, res, next) => {
    res.locals.user       = req.session.user || null;
    res.locals.success    = req.flash('success');
    res.locals.error      = req.flash('error');
    res.locals.appName    = process.env.APP_NAME || 'Quản Lý Vé Số';
    next();
};

module.exports = { isAuthenticated, isAdmin, setLocals };
